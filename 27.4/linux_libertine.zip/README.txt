LOFP - Libertine Open Fonts Project

1. OPEN FONTS PROJECT'S AIMS
We work on a serif and organic grotesque font-family for practical use in documents. 
Our project aims at creating a free alternative to the standard W*ndows Font (T*mes).
But neveretheless Libertine and Biolinum are not a clone of any common font! 
They have been developed from scratch and go different ways in typography 
than the Times or Arial. Just the useability and the dimensions shall be similar, 
Libertine should be even better for typical office use! If you want Times- and 
Arial-clones go elsewhere. If you just need reliable and good typography 
give our fonts a chance. If you want to know more about the design of 
Libertine and Biolinum, have a look at our website.

2. LICENSE AND OPENSOURCE
We publish our fonts under the terms of the GPL (see GPL.txt) and OFL (OFL.txt)
-> see also LICENCE.txt!
The OpenSource-tool Fontforge is used as font editor (see http://fontforge.sf.net).

3. FONT FORMATS: TTF, OTF, SVG, WOFF
The font files are available as TTF (TrueType), OTF (OpenType),
SVG (Scalable Vector Graphics) and WOFF (Web Open Font Format) fonts. 
The TTF-/WOFF-Family is called "Linux Libertine" and "Linux Biolinum"
and the OTF/SVG "LinuxLibertine O" and "Linux Biolinum O".

So that both types can be installed and used parallely.
Most often TTF is the better supported format though OTF has advances in printing. 
Decide yourself what is better for your purpose. OpenType-features are equally 
available in both fonts. Note that OpenOffice doesn’t support OTFs, yet.

4. THE LINUX BIOLINUM FONT FACE
Please note: 
While you use Libertine-Fonts without any warranty anyway, 
take special care with this young font face.

5. HINTING
The TrueType-hinting is a complex technique and our editor FontForge doesn't support 
full possibilities (but it becomes alot better version by version) ...
Since version 2.7 also the normal TTFs are hinted. If you don't like this, send me a mail. 
You may also try the OpenTypes (which contain PS-Hintings which are quite 
good supported by FontForge).

6. DOWNLOAD AND CONTACT
We publish our fonts at http://www.linuxlibertine.org/.

7. THE UNDERLINED VARIANT
Please note: 
The underlined variant is recently not being maintained because its concept 
doesn’t seem to be sofware-technically reliable and because of lack of interest.
The advantage of this font was that g, commas, cedillas... were not overprinted 
by the line anymore. For technical reasons the space was not underlined but 
you could use the _ instead. In this font it had the width of the space and 
the line was at hight of the underline. The underlined variant used 
an older font outline.

Philipp Poll -- gillian at linuxlibertine.org

