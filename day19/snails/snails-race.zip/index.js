document.addEventListener('DOMContentLoaded', () => {
  console.log('it works');
})